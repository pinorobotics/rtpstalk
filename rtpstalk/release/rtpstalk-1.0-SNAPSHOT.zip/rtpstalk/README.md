**rtpstalk** - Java module to 

Supports RTPS 2.3

# Requirements

Java 17+

# Download

You can download **rtpstalk** from <https://github.com/pinorobotics/rtpstalk/releases>

Or you can add dependency to it as follows:

Gradle:

```
dependencies {
    implementation 'io.github.pinorobotics:rtpstalk:1.0'
}
```

# Links

[Documentation](http://pinoweb.atwebpages.com/rtpstalk)

# Contributors

xxxxxxxx
ros2 run demo_nodes_cpp talker
ros2 run demo_nodes_cpp listener
