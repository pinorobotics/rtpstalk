**rtpstalk** - Java module to 

# Requirements

Java 17+

# Download

You can download **rtpstalk** from <https://github.com/pinorobotics/rtpstalk/releases>

Or you can add dependency to it as follows:

Gradle:

```
dependencies {
    compile 'io.github.pinorobotics:rtpstalk:1.0'
}
```

# Links

[Documentation](http://pinoweb.atwebpages.com/rtpstalk)

# Contributors

xxxxxxxx
